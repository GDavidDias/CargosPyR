const getAllInscriptosPyR = require('./getAllInscriptosPyR.js');

module.exports={
    getAllInscriptosPyR,
    
}