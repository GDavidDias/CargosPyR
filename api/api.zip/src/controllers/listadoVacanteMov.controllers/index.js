const createListadoVacMov = require('./createListadoVacMov.js');
const getListadoVacMov = require('./getListadoVacMov.js');
const editListadoVacMov = require('./editListadoVacMov.js');

module.exports={
    createListadoVacMov,
    getListadoVacMov, 
    editListadoVacMov
};